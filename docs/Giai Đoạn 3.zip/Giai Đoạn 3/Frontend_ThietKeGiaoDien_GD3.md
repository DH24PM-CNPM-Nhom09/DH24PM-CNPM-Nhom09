# Tài liệu Thiết kế Giao diện — Frontend (Web & Mobile)
**Hệ thống Quản lý Tuyển sinh Sau đại học — Giai đoạn 3 (GĐ3)**

**Vai trò:** Thí sinh — nền tảng: Web (Next.js) & Mobile (Flutter)

---

**Người thực hiện:** Nguyễn Phúc Khang — Frontend Developer (Web & Mobile), phụ trách vai trò Thí sinh
**Ngày cập nhật:** 26/09/2026
**Repository:** github.com/haidpm235414/DH24PM-CNPM-Nhom09 — nhánh **Frontend**, thư mục **frontend/web/** và **frontend/mobile/**

---

## 1. Mục tiêu và phạm vi tài liệu

Tài liệu này mô tả toàn bộ phần **giao diện người dùng (Frontend)** cho vai trò **Thí sinh** trong Hệ thống Quản lý Tuyển sinh Sau đại học, bao gồm ba nội dung chính theo đúng yêu cầu giai đoạn 3:

- **Design System** — hệ thống thiết kế dùng chung: bảng màu, typography, khoảng cách, bo góc, thư viện component — áp dụng đồng nhất trên cả hai nền tảng.
- **UI Mockup** — ảnh chụp màn hình thật (không phải bản vẽ phác thảo) lấy trực tiếp từ ứng dụng đang chạy, kèm mô tả chức năng và các trường dữ liệu của từng màn hình.
- **Hợp đồng API (API Contract)** — danh sách endpoint mà Frontend đã lập trình sẵn theo, làm cơ sở để nhóm Backend triển khai đúng và đủ.

Phạm vi áp dụng: toàn bộ 10 màn hình thuộc luồng nghiệp vụ của thí sinh, trên hai nền tảng **Web** (chạy trên trình duyệt, dùng cho máy tính) và **Mobile** (ứng dụng Android/iOS cài trên điện thoại), dùng chung một bộ dữ liệu và một bộ API phía sau.

---

## 2. Nguyên tắc thiết kế (Design Principles)

- **Nhất quán đa nền tảng (Cross-platform consistency):** Web và Mobile dùng chung một bộ token màu sắc, khoảng cách và bo góc, chỉ khác cách bố trí (layout) cho phù hợp kích thước màn hình.
- **Rõ ràng trạng thái (Status clarity):** mọi trạng thái hồ sơ (đang thẩm định, đã duyệt, từ chối, trúng tuyển, dự bị...) đều được thể hiện bằng badge màu sắc riêng biệt, tránh gây hiểu nhầm cho thí sinh.
- **Ưu tiên nội dung (Content-first):** giao diện tối giản, hạn chế chi tiết trang trí không cần thiết, tập trung vào thao tác chính của thí sinh (nộp hồ sơ, theo dõi trạng thái).
- **Khả năng truy cập (Accessibility):** độ tương phản màu chữ/nền đạt chuẩn WCAG AA cho các khối văn bản chính; cỡ chữ tối thiểu 12px; vùng chạm (tap target) trên mobile tối thiểu 44x44px.
- **Thiết kế đáp ứng (Responsive/Adaptive):** bản Web tự co giãn từ khung máy tính lớn xuống màn hình điện thoại (sidebar chuyển thành drawer menu); bản Mobile dùng Bottom Navigation Bar phù hợp thao tác một tay.

---

## 3. Design System

### 3.1. Bảng màu (Color Palette)

Bảng màu được xây dựng theo mô hình 5 nhóm ngữ nghĩa: **Navy** (thương hiệu/chủ đạo), **Accent** (điểm nhấn hành động), và ba nhóm trạng thái **Success / Warning / Danger** cùng nhóm **Info** cho thông báo. Mỗi nhóm có biến thể đậm/nhạt (ví dụ accent50) để dùng làm nền cho badge và banner mà không chói mắt.

| Màu | Mã màu | Vai trò sử dụng |
|---|---|---|
| navy900 | `#142B4D` | Nền header, sidebar, nút chính |
| navy800 | `#1B3A66` | Trạng thái hover của navy900 |
| navy700 | `#20477A` | Icon, viền nhấn |
| navy50 | `#EEF2F8` | Nền nhạt cho khối thông tin |
| accent | `#E8734A` | Nút hành động chính, badge nổi bật |
| accentDark | `#C85A33` | Hover của accent |
| accent50 | `#FDEEE7` | Nền nhạt cho accent |
| success | `#16A34A` | Trạng thái: Đã duyệt, Đã trúng tuyển |
| success50 | `#EAF7EE` | Nền banner/badge success |
| warning | `#D97706` | Trạng thái: Đang chờ, Danh sách dự bị |
| warning50 | `#FEF3E2` | Nền banner/badge warning |
| danger | `#DC2626` | Trạng thái: Từ chối, lỗi |
| danger50 | `#FDECEC` | Nền banner/badge danger |
| info | `#2563EB` | Thông báo, ghi chú hướng dẫn |
| info50 | `#EAF1FE` | Nền banner info |

Ngoài ra, thang màu trung tính (gray scale) gồm 9 mức từ **gray25** (gần trắng) đến **gray900** (gần đen) dùng cho văn bản, viền và nền phụ.

### 3.2. Typography

- **Font chữ:** Be Vietnam Pro (Google Fonts) — chọn vì hỗ trợ đầy đủ và đẹp cho tiếng Việt có dấu, đồng thời có nhiều độ đậm (weight) phù hợp phân cấp thông tin.
- **Thang cỡ chữ:** theo hệ số chuẩn Tailwind, từ 12px (chú thích nhỏ) đến 30px (tiêu đề trang).
- **Độ đậm:** 400 (nội dung thường), 600 (nhãn, nút), 700 (tiêu đề).

### 3.3. Bo góc và khoảng cách (Radius & Spacing)

| Thành phần | Giá trị | Lý do lựa chọn |
|---|---|---|
| Ô nhập liệu (Input) | bo góc 10px | Mềm mại, dễ chịu khi nhìn danh sách form dài |
| Thẻ (Card) | bo góc 14px | Phân tách rõ khối nội dung mà không quá bo tròn |
| Khoảng đệm chuẩn | bội số của 4px | Đồng bộ theo thang spacing của Tailwind, dễ maintain |

### 3.4. Thư viện Component dùng chung

Mỗi component được cài đặt song song trên cả hai nền tảng, đảm bảo cùng hành vi (behavior) và giao diện, chỉ khác cú pháp theo ngôn ngữ lập trình (React/TypeScript cho Web, Dart cho Mobile):

| Component | Web (Next.js) | Mobile (Flutter) | Trạng thái / Biến thể hỗ trợ |
|---|---|---|---|
| Button | `Button.tsx` | `AppButton` | primary, ghost, danger; disabled; loading (spinner) |
| Input | `Input.tsx` | `AppTextField` | label, dấu bắt buộc (*), hint text, trạng thái lỗi |
| Card | `Card.tsx` | `AppCard` | bo góc 14px, đổ bóng nhẹ, padding chuẩn 16–24px |
| Badge | `Badge.tsx` | `StatusBadge` | success / warning / danger / info / neutral |
| OTP Input | `OtpInput.tsx` | `otp_input.dart` | nhiều ô số, tự chuyển ô kế tiếp khi nhập |

---

## 4. Kiến trúc và công nghệ sử dụng

| Hạng mục | Web | Mobile |
|---|---|---|
| Framework | Next.js 14 (App Router) | Flutter (Dart) |
| Ngôn ngữ | TypeScript + React 18 | Dart |
| Styling | TailwindCSS | Material 3 theme tùy biến (app_theme.dart) |
| Định tuyến (Routing) | File-based routing (src/app) | IndexedStack + Bottom NavigationBar |
| Gọi API | fetch qua lớp api.ts (chuẩn hóa lỗi, header) | package http qua lớp api_service.dart |
| Trạng thái dữ liệu | Mock-first: cờ USE_MOCK trong api.ts | Mock-first: cờ useMock trong api_service.dart |
| PWA | manifest.json + service worker (sw.js) | — (native app) |

Cả hai nền tảng đều triển khai theo mô hình **Mock-first**: toàn bộ luồng UI/UX được xây dựng và kiểm thử hoàn chỉnh với dữ liệu giả lập trước, giúp Frontend không bị phụ thuộc tiến độ của Backend. Khi Backend triển khai API thật, chỉ cần đổi một cờ cấu hình (xem mục 9) mà không phải sửa lại giao diện.

---

## 5. Luồng người dùng chính (User Flow)

Luồng thao tác chính của một thí sinh từ khi truy cập hệ thống đến khi hoàn tất nhập học:

- **Bước 1 — Xác thực:** Đăng ký tài khoản hoặc Đăng nhập bằng Google → nếu quên mật khẩu, xác thực qua OTP.
- **Bước 2 — Tổng quan:** Xem Dashboard để nắm nhanh mã hồ sơ, trạng thái thẩm định và trạng thái xét tuyển.
- **Bước 3 — Nộp hồ sơ:** Thực hiện wizard 4 bước (Thông tin cá nhân → Ngành/đợt tuyển sinh → Tải hồ sơ → Xác nhận & nộp).
- **Bước 4 — Theo dõi:** Vào màn hình Hồ sơ xét tuyển để xem trạng thái từng tài liệu (Hợp lệ / Đang kiểm tra / Không hợp lệ).
- **Bước 5 — GVHD (chỉ bậc Tiến sĩ):** Theo dõi trạng thái yêu cầu đăng ký giảng viên hướng dẫn.
- **Bước 6 — Khiếu nại (nếu cần):** Gửi yêu cầu phúc khảo điểm hoặc khiếu nại liên quan hồ sơ.
- **Bước 7 — Xác nhận nhập học:** Khi có kết quả trúng tuyển, xác nhận nhập học chính thức trong hệ thống.
- **Xuyên suốt:** có thể vào Hồ sơ cá nhân bất kỳ lúc nào để cập nhật thông tin liên hệ.

---

## 6. UI Mockup — Chi tiết từng màn hình (ảnh chụp thực tế)

Toàn bộ ảnh dưới đây được chụp **trực tiếp từ bản Web (Next.js) đang chạy tại localhost:3000**, phản ánh đúng 100% giao diện thật đang hoạt động (chế độ dữ liệu MOCK, chờ Backend triển khai API thật — xem mục 9). Bản Mobile (Flutter) triển khai đầy đủ tương đương, chỉ khác cách bố trí cho phù hợp màn hình điện thoại (xem cấu trúc trong thư mục `frontend/mobile/lib/screens/`).

### 1. Đăng nhập (`/login`)

**Mục đích:** Điểm vào hệ thống; thí sinh đăng nhập bằng tài khoản Google (OAuth2) để đảm bảo định danh chính xác, hạn chế tài khoản ảo.

- Nút "Đăng nhập với Google" — luồng OAuth2 chuẩn.
- Liên kết "Lấy lại quyền truy cập" khi quên tài khoản Google đã đăng ký.
- Liên kết "Đăng ký ngay" cho người dùng chưa có tài khoản.

![Màn hình Đăng nhập](images/01_dangnhap.jpg)

### 2. Đăng ký tài khoản (`/register`)

**Mục đích:** Cho phép thí sinh mới tạo hồ sơ tài khoản ban đầu (họ tên, email, số điện thoại) trước khi liên kết đăng nhập Google.

- Trường bắt buộc: Họ và tên, Email, Số điện thoại — có kiểm tra định dạng (validation) ngay trên form.
- Nút "Tiếp tục" chuyển sang bước xác thực kế tiếp.

![Màn hình Đăng ký](images/02_dangky.jpg)

### 3. Quên mật khẩu (`/forgot-password`)

**Mục đích:** Khôi phục quyền truy cập khi thí sinh không nhớ thông tin đăng nhập, xác thực qua mã OTP gửi tới email/số điện thoại.

- Nhận một trong hai: email hoặc số điện thoại đã đăng ký.
- Nút "Gửi mã xác thực" kích hoạt luồng OTP (component OtpInput dùng lại ở bước xác nhận kế tiếp).

![Màn hình Quên mật khẩu](images/03_quenmatkhau.jpg)

### 4. Trang chủ / Tổng quan (`/dashboard`)

**Mục đích:** Màn hình trung tâm sau đăng nhập — cho thí sinh nắm nhanh tình trạng hồ sơ mà không cần đào sâu vào từng mục.

- Thẻ tổng quan: mã hồ sơ, ngành đăng ký, bậc đào tạo, đợt tuyển sinh.
- 2 badge trạng thái độc lập: **Đang thẩm định / Đã duyệt** (reviewStatus) và **Chưa có kết quả / Trúng tuyển** (admissionStatus).
- 3 thẻ số liệu nhanh: Hồ sơ, Kết quả xét tuyển, GVHD (bậc Tiến sĩ).
- Lối tắt: "Xem chi tiết hồ sơ" và "Gửi khiếu nại / phúc khảo".

![Màn hình Tổng quan](images/04_dashboard.jpg)

### 5. Hồ sơ xét tuyển (`/application`)

**Mục đích:** Danh sách chi tiết các tài liệu đã nộp kèm trạng thái kiểm duyệt riêng cho từng file, và khu vực tải thêm tài liệu mới.

- Mỗi tài liệu hiển thị: tên file, loại tài liệu, dung lượng, badge trạng thái (Hợp lệ / Đang kiểm tra / Không hợp lệ).
- Khu vực "Tải lên tài liệu mới": chọn loại tài liệu (dropdown 7 loại chuẩn) + nút chọn file.
- Ràng buộc: tối đa 5MB/file, định dạng PDF/JPG/PNG.

![Màn hình Hồ sơ xét tuyển](images/05_hosoxettuyen.jpg)

### 6. Tạo hồ sơ xét tuyển — Wizard 4 bước (`/application/new`)

**Mục đích:** Luồng nộp hồ sơ chính, chia nhỏ thành 4 bước để giảm tải nhận thức cho thí sinh, có thanh tiến trình (stepper) trực quan ở đầu trang.

- **Bước 1 — Thông tin cá nhân:** họ tên, ngày sinh, số CCCD/CMND.
- **Bước 2 — Ngành & đợt tuyển sinh:** bậc đào tạo (Thạc sĩ/Tiến sĩ), đợt tuyển sinh, ngành đăng ký, ghi chú thêm.
- **Bước 3 — Tải hồ sơ:** khu vực kéo-thả/chọn nhiều file, giới hạn 5MB/file và 30MB/tổng hồ sơ.
- **Bước 4 — Xác nhận & nộp:** tổng hợp lại toàn bộ thông tin đã nhập để thí sinh xác nhận trước khi nộp chính thức.
- Có thể quay lại bước trước bất kỳ lúc nào bằng nút "← Quay lại" mà không mất dữ liệu đã nhập.

![Màn hình Wizard tạo hồ sơ](images/06_wizard_taohoso.jpg)

### 7. Giảng viên hướng dẫn — GVHD (`/gvhd`)

**Mục đích:** Chỉ áp dụng cho bậc **Tiến sĩ** — theo dõi trạng thái yêu cầu đăng ký giảng viên hướng dẫn đã gửi.

- Thông tin giảng viên: tên, khoa/bộ môn.
- Badge trạng thái: **Đang chờ phản hồi / Đã chấp nhận hướng dẫn / Đã từ chối**.
- Banner hướng dẫn tương ứng từng trạng thái (ví dụ: gợi ý liên hệ Phòng Đào tạo Sau đại học nếu bị từ chối).

![Màn hình GVHD](images/07_gvhd.jpg)

### 8. Khiếu nại / Phúc khảo (`/complaint`)

**Mục đích:** Kênh chính thức để thí sinh gửi yêu cầu phúc khảo điểm hoặc khiếu nại liên quan đến quá trình xét tuyển.

- Chọn loại yêu cầu (dropdown: Phúc khảo điểm / Khiếu nại khác...).
- Nhập mã hồ sơ liên quan và nội dung chi tiết (textarea).
- Nút "Gửi yêu cầu" — dữ liệu được POST tới endpoint `/complaints` (xem mục 8).

![Màn hình Khiếu nại](images/08_khieunai.jpg)

### 9. Xác nhận nhập học (`/admission-confirm`)

**Mục đích:** Bước cuối cùng của luồng nghiệp vụ — chỉ hiển thị hành động xác nhận khi hồ sơ đã có kết quả trúng tuyển chính thức.

- Nếu **admissionStatus = Trúng tuyển:** hiện nút "Xác nhận nhập học ngay".
- Nếu **đã xác nhận / đã nhập học:** hiện banner success xác nhận thành công.
- Nếu **dự bị:** hiện banner warning. Nếu **chưa có kết quả:** hiện thông báo trung tính (như ảnh dưới).

![Màn hình Xác nhận nhập học](images/09_xacnhannhaphoc.jpg)

### 10. Hồ sơ cá nhân (`/profile`)

**Mục đích:** Cho phép thí sinh xem và cập nhật thông tin liên hệ cá nhân bất kỳ lúc nào, độc lập với luồng nộp hồ sơ xét tuyển.

- Các trường: Họ và tên, Ngày sinh, Giới tính, Số CCCD/CMND, Số điện thoại, Email, Địa chỉ.
- Nút "Lưu thay đổi" gọi `PATCH /candidates/me` (xem mục 8).

![Màn hình Hồ sơ cá nhân](images/10_hosocanhan.jpg)

---

## 7. Quy tắc nghiệp vụ đã triển khai trên giao diện (khớp `admission_db` v3)

- **2 trục trạng thái độc lập:** `reviewStatus` (trạng thái duyệt hồ sơ: đang thẩm định / đã duyệt / từ chối) và `admissionStatus` (trạng thái trúng tuyển: chưa có kết quả / trúng tuyển / dự bị / đã xác nhận / đã nhập học) — hai trục này **độc lập hoàn toàn**, hiển thị bằng 2 badge riêng biệt, không gộp chung để tránh thí sinh hiểu nhầm.
- **Giới hạn tải file:** tối đa **5MB/file** (5120KB), tổng tối đa **30MB/hồ sơ** — kiểm tra ngay trên giao diện trước khi gửi lên server.
- **document_type:** gồm đúng **7 giá trị chuẩn** theo thiết kế CSDL (ví dụ: Văn bằng, Bảng điểm, Chứng chỉ ngoại ngữ...).
- **Luồng GVHD:** (Đang chờ / Đã chấp nhận / Đã từ chối) **chỉ hiển thị cho bậc Tiến sĩ**; bậc Thạc sĩ không có mục này trong menu.
- **candidate_id** luôn được suy ra từ token đăng nhập phía server, giao diện không cho phép người dùng tự nhập hay chỉnh sửa mã định danh này.

---

## 8. Hợp đồng API (API Contract) — bàn giao cho Backend

Frontend (cả Web lẫn Mobile) đã lập trình đầy đủ theo hợp đồng REST API dưới đây, hiện đang chạy ở **chế độ MOCK** (dữ liệu giả lập ngay trong ứng dụng, phục vụ demo/kiểm thử UI trong lúc chờ Backend).

| Method | Endpoint | Chức năng |
|---|---|---|
| POST | `/auth/google` | Đăng nhập bằng Google OAuth2 |
| POST | `/auth/forgot-password` | Gửi mã OTP quên mật khẩu |
| POST | `/auth/reset-password` | Đặt lại mật khẩu bằng mã OTP |
| GET / PATCH | `/candidates/me` | Xem / cập nhật thông tin thí sinh hiện tại |
| POST | `/applications` | Nộp hồ sơ xét tuyển mới (wizard bước 4) |
| GET | `/applications/me` | Xem hồ sơ xét tuyển của tôi |
| POST | `/applications/me/documents` | Tải tài liệu đính kèm cho hồ sơ hiện tại |
| POST | `/applications/{id}/documents` | Tải tài liệu theo mã hồ sơ cụ thể (multipart/form-data) |
| GET | `/applications/me/supervisor-request` | Xem trạng thái yêu cầu đăng ký GVHD (bậc Tiến sĩ) |
| POST | `/complaints` | Gửi khiếu nại / yêu cầu phúc khảo |

Frontend chỉ cần Backend triển khai **đúng một bộ API duy nhất** theo bảng trên — dùng chung cho cả Web và Mobile, **không cần xây API riêng cho từng nền tảng**, giúp tiết kiệm đáng kể thời gian phát triển của nhóm Backend.

---

## 9. Kế hoạch chuyển từ dữ liệu MOCK sang API thật

Khi Backend hoàn tất triển khai API theo đúng hợp đồng ở mục 8, việc kết nối chỉ gồm các bước sau, không cần viết lại giao diện:

- **Web:** đổi giá trị `NEXT_PUBLIC_API_BASE_URL` trong file `.env.local` thành URL server Backend thật.
- **Mobile:** mở `lib/services/api_service.dart`, đổi `static const bool useMock = true;` thành `false`, và cập nhật `apiBase` thành URL thật.
- **Đăng nhập Google thật (Mobile):** bổ sung gói `google_sign_in` vào `pubspec.yaml`, lấy idToken thật để gọi `apiService.loginWithGoogle(idToken)`.
- **Upload file thật (Mobile):** bổ sung gói `file_picker`, cập nhật hàm `uploadDocument` để dùng `http.MultipartRequest` gửi file thật.

---

## 10. Trạng thái hiện tại và bước tiếp theo

- **[Hoàn thành]** Web (Next.js): đủ 10 màn hình, đã push lên nhánh `Frontend`, thư mục `frontend/web/`.
- **[Hoàn thành]** Mobile (Flutter): đủ 10 màn hình, đã chạy thử thành công trên thiết bị Android thật, đã push lên nhánh `Frontend`, thư mục `frontend/mobile/`.
- **[Đang chờ]** Backend triển khai API thật theo đúng hợp đồng ở mục 8 để Frontend chuyển từ MOCK sang kết nối thật.
- **[Cập nhật 25/09/2026]** CSDL `admission_db_v3.sql` trên nhánh `main` vừa được vá lỗi tương thích MariaDB: bỏ `ON UPDATE UTC_TIMESTAMP()` (không hợp lệ trên MariaDB) và thay bằng 2 trigger tự cập nhật thời gian (`trg_admission_batch_updated_at`, `trg_system_config_updated_at`); sửa thủ tục `sp_recalc_application_total_score()` dùng `INSERT ... ON DUPLICATE KEY UPDATE` để không bị thiếu bản ghi xếp hạng; thêm `IF NOT EXISTS` cho các index. Đây là các thay đổi nội bộ ở tầng CSDL — **không đổi tên bảng/cột và không đổi API contract ở mục 8**, nên Frontend hiện tại không cần chỉnh sửa gì để tương thích.
- **[Đề xuất]** Đồng bộ nhánh `Frontend` với nhánh `main` (hiện đang lệch nhiều commit, bao gồm bản CSDL v3 mới) để tránh xung đột khi tích hợp cuối giai đoạn.
