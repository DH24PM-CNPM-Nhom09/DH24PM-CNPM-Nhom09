# Thiết kế Cơ sở Dữ liệu Chi tiết (DDD) — Phân hệ Quản lý Tuyển sinh

| Mục | Nội dung |
|---|---|
| Người thực hiện | Lâm Hoài An — QA / Security & Data Specialist |
| Nguồn | `admission_db.sql` v3 — 40 bảng / 10 miền nghiệp vụ / 11 trigger / 1 procedure / 9 index |
| Mục đích | Data dictionary đầy đủ + lý do thiết kế, dùng làm phụ lục cho DDD chung của nhóm |

## Quy ước thiết kế (áp dụng cho toàn bộ 40 bảng)

- `snake_case`; khóa chính `<ten_bang>_id BIGINT UNSIGNED AUTO_INCREMENT`
- Tách khóa chính nội bộ và mã nghiệp vụ (cột `*_code`, có UNIQUE riêng)
- Tiền tệ: `DECIMAL(15,2)`; thời gian lưu **UTC**, tầng ứng dụng quy đổi UTC+7 khi hiển thị
- Trạng thái kiểm soát bằng `CHECK (status IN (...))` — **yêu cầu MariaDB ≥ 10.2.7** để CHECK được thực thi thật, không chỉ parse
- "Người thực hiện" luôn là FK tới `staff_account`, không lưu chuỗi tự do
- Xoá mềm (`deleted_at`) áp dụng cho các bảng danh mục/định danh (batch, major, account, candidate, lecturer, document); các bảng nghiệp vụ/log không xoá mềm vì cần giữ toàn vẹn lịch sử

---

## MIỀN 1 — Danh mục & Cấu hình đợt tuyển sinh

**`admission_batch`** — Đợt tuyển sinh

| Cột | Kiểu & ràng buộc | Mô tả |
|---|---|---|
| batch_id | BIGINT UNSIGNED, PK | |
| batch_code | VARCHAR(30), UNIQUE, NOT NULL | Mã đợt |
| batch_name | VARCHAR(255), NOT NULL | |
| degree_level | VARCHAR(10), CHECK IN (THAC_SI, TIEN_SI) | |
| registration_start_at / registration_end_at | DATETIME, NOT NULL | CHECK end > start |
| exam_start_at / exam_end_at | DATETIME, NULL | CHECK end > start nếu cả 2 có giá trị |
| legal_basis | VARCHAR(100), NULL | VD: Thông tư 53/2026/TT-BGDĐT |
| status | VARCHAR(20), DEFAULT 'DRAFT' | CHECK IN (DRAFT, OPEN, CLOSED, IN_REVIEW, COMPLETED, CANCELLED) |
| deleted_at, created_at, updated_at | DATETIME | Soft delete + audit thời gian |

**`admission_major`** — Danh mục ngành: `major_id` PK, `major_code` UK, `major_name`, `degree_level` (CHECK THAC_SI/TIEN_SI), `faculty_name`, `status` (ACTIVE/INACTIVE), `deleted_at`.

**`admission_batch_major`** — Chỉ tiêu ngành theo đợt (N-N giữa batch và major): `batch_major_id` PK, `batch_id`/`major_id` FK, UNIQUE(batch_id, major_id), `quota` (CHECK > 0), `benchmark_score` (0–10, có thể NULL trước khi chốt điểm chuẩn), `status` (CONFIGURING/APPROVED/OPEN/CLOSED).

**`admission_condition`** — Điều kiện xét tuyển theo Điều 6 TT53: `condition_id` PK, `batch_major_id` FK, `condition_code`, `description` (TEXT), `min_gpa`, `required_certificate`, `is_mandatory` (bool).

**`admission_committee`** — Hội đồng tuyển sinh/thi: `committee_id` PK, `batch_major_id` FK (**NULL được** — hội đồng cấp trường không gắn 1 ngành cụ thể), `committee_name`, `decision_no`, `formed_at`, `status` (ACTIVE/DISSOLVED).

**`committee_member`** — Thành viên hội đồng: `member_id` PK, `committee_id` FK, `full_name`, `lecturer_code`, `role_in_committee` (CHU_TICH/THU_KY/UY_VIEN).

**`exam_subject`** — Môn thi/hình thức xét tuyển: `subject_id` PK, `batch_major_id` FK, `subject_name`, `exam_format` (THI_VIET/PHONG_VAN/XET_HO_SO), `weight` (>0, mặc định 1.00 — dùng để tính `total_score` có trọng số), `max_score` (mặc định 10.00).

---

## MIỀN 2 — Người dùng nội bộ, Phân quyền & Cấu hình chung

**`staff_account`**: `staff_account_id` PK, `staff_code` UK, `full_name`, `email` UK, `password_hash` (VARCHAR 255, **NULL từ v3** — dự phòng, xem mục "Thay đổi v3"), `status` (ACTIVE/LOCKED/DISABLED), `deleted_at`.

**`role`**: `role_id` PK, `role_code` UK (VD: `CAN_BO_TUYEN_SINH`, `HOI_DONG`, `LANH_DAO_KHOA`, `ADMIN`, `BGH_KHTC`), `role_name`. *(Chi tiết ánh xạ actor ↔ role_code xem file `MaTranPhanQuyen_GD3.md`)*.

**`staff_role`**: bảng N-N gán vai trò — `staff_role_id` PK, `staff_account_id`/`role_id` FK, UNIQUE(staff_account_id, role_id) → **1 nhân sự có thể giữ nhiều vai trò cùng lúc** (ví dụ vừa `CAN_BO_TUYEN_SINH` vừa `ADMIN`).

**`system_config`**: cấu hình dùng chung dạng key-value — `config_key` VARCHAR(100) **là PK** (không dùng ID số), `config_value`, `description`, `updated_at`. Dùng cho: hạn OTP, dung lượng file tối đa, điểm ưu tiên...

---

## MIỀN 3 — Tài khoản & Hồ sơ cá nhân thí sinh

**`candidate_account`**: `account_id` PK, `username` UK, `email`/`phone_number` UK (đều **NULL được** vì thí sinh chỉ cần 1 trong 2 để định danh), `password_hash` (**NULL từ v3**), `status` (PENDING_VERIFY/ACTIVE/LOCKED), `failed_login_count` (mặc định 0, dùng để khoá tạm sau N lần sai), `locked_until` (tự mở khoá sau thời điểm này), `deleted_at`, `created_at`.

**`otp_verification`**: `otp_id` PK, `account_id` FK, `purpose` (REGISTER/RESET_PASSWORD/SENSITIVE_ACTION), `otp_code_hash` (**hash, không lưu OTP dạng plain**), `sent_count`, `expires_at`, `verified_at`.

**`candidate`**: hồ sơ cá nhân thật, tách khỏi tài khoản đăng nhập — `candidate_id` PK, `account_id` FK **UNIQUE** (1-1 với candidate_account), `full_name`, `dob`, `gender` (NAM/NU/KHAC, NULL được), `id_number` UK (CCCD/CMND, NULL được vì có thể chưa kê khai ngay lúc tạo tài khoản), `address`, `nationality` (mặc định 'Việt Nam'), `deleted_at`.

---

## MIỀN 4 — Hồ sơ xét tuyển, Minh chứng, Lệ phí & Hướng dẫn NCS

**`application`** — bảng trung tâm của toàn hệ thống:

| Cột | Kiểu & ràng buộc | Mô tả |
|---|---|---|
| application_id | PK | |
| application_code | VARCHAR(30) UK | |
| candidate_id | FK → candidate | |
| batch_major_id | FK → admission_batch_major | Nguyện vọng ngành trong đợt |
| review_status | CHECK IN (DRAFT, SUBMITTED, UNDER_REVIEW, NEEDS_SUPPLEMENT, APPROVED, REJECTED) | Trục thẩm định |
| admission_status | CHECK IN (NONE, WAITLISTED, ADMITTED, CONFIRMED, ENROLLED) | Trục kết quả xét tuyển |
| is_cancelled | TINYINT(1) | Thí sinh chủ động rút hồ sơ |
| active_slot | BIGINT, **GENERATED COLUMN** (VIRTUAL) | = NULL nếu is_cancelled=1, ngược lại = batch_major_id |
| submitted_at, deleted_at, created_at | | |

> **Thiết kế đáng chú ý:** trạng thái tách làm 2 trục độc lập (`review_status`/`admission_status`) thay vì gộp vào 1 cột nhiều giá trị — dễ bảo trì và cho trigger đồng bộ có điểm neo rõ ràng. Ràng buộc `UNIQUE(candidate_id, active_slot)` dùng cột generated để **cho phép thí sinh nộp lại hồ sơ mới sau khi rút** (vì lúc đó active_slot = NULL, không đụng UNIQUE) nhưng vẫn chặn nộp trùng nguyện vọng khi hồ sơ đang hoạt động.

**`application_document`**: `document_id` PK, `application_id` FK, `document_type` (VAN_BANG/BANG_DIEM/CHUNG_CHI_NGOAI_NGU/DE_CUONG_NCS/THU_GIOI_THIEU/CONG_BO_KHOA_HOC/KHAC), `file_name`, `file_path`, `file_hash` CHAR(64) (SHA-256, bảo vệ toàn vẹn tệp), `file_size_kb` (CHECK 0 < x ≤ 5120, tức **giới hạn 5MB/tệp**; giới hạn 30MB/hồ sơ kiểm soát bằng trigger riêng), `verify_status` (PENDING/VALID/INVALID), `uploaded_at`.

**`lecturer`**: danh mục giảng viên dùng làm GVHD — `lecturer_id` PK, `lecturer_code` UK, `full_name`, `email` UK, `faculty_name`, `status`, `deleted_at`. *(Thay thế cách cũ lưu tên chữ tự do, không quản lý được trạng thái.)*

**`research_proposal`**: đề cương NCS, **chỉ áp dụng bậc Tiến sĩ** — `proposal_id` PK, `application_id` FK **UNIQUE** (1 hồ sơ tối đa 1 đề cương), `document_id` FK, `research_topic`, `research_field`, `preferred_lecturer_id` FK (NULL được — GVHD mong muốn).

**`supervisor_request`**: quy trình đồng ý/từ chối hướng dẫn — `request_id` PK, `proposal_id`/`lecturer_id` FK, `status` (PENDING/ACCEPTED/REJECTED), `requested_at`, `responded_at`, `response_note`.

**`application_payment`**: `payment_id` PK, `application_id` FK, `amount` (≥0), `payment_method` (BANK_TRANSFER/MOMO/VNPAY/KHAC), `transaction_code` UK **NULL được** (xem lưu ý ở mục 6 file ERD — nhiều NULL không vi phạm UNIQUE, đúng chuẩn MariaDB), `gateway_status` (PENDING/SUCCESS/FAILED/REFUNDED/CANCELLED/EXPIRED), `receipt_no`, `paid_at`.

---

## MIỀN 5 — Thẩm định & Lịch sử trạng thái

**`application_review`**: `review_id` PK, `application_id` FK, `reviewer_staff_id` FK (NULL được — cho phép ghi nhận review tự động), `review_type` (AUTO_CHECK/MANUAL_REVIEW), `review_result` (PASS/FAIL/NEEDS_SUPPLEMENT), `note`, `reviewed_at`.

**`supplement_request`**: `request_id` PK, `application_id` FK, `requested_by_staff_id` FK, `content`, `deadline`, `status` (PENDING/RESOLVED/EXPIRED), `responded_at`.

**`application_status_history`**: `history_id` PK, `application_id` FK, `old_status`/`new_status` (VARCHAR 150 — lưu dạng ghép chuỗi nhiều trường, xem trigger cuối file), `changed_by_type` (STAFF/SYSTEM/CANDIDATE), `changed_by_staff_id` FK NULL, `reason`, `changed_at`.

> **Ghi chú thiết kế:** bảng này **tách riêng khỏi `audit_log`** dù cùng là "lịch sử" — vì đây là log nghiệp vụ cần truy vết pháp lý (ai đổi trạng thái hồ sơ, khi nào, vì sao), trong khi `audit_log` (Miền 10) là nhật ký kỹ thuật tự do cho mọi thao tác khác. Không gộp 2 bảng để tránh lẫn lộn mục đích sử dụng.

---

## MIỀN 6 — Tổ chức xét tuyển / thi

**`exam_room`**: `room_id` PK, `batch_id` FK, `room_code`, UNIQUE(batch_id, room_code), `location`, `capacity` (>0).

**`exam_assignment`**: số báo danh & phòng thi — `assignment_id` PK, `application_id` FK **UNIQUE**, `room_id` FK, `sbd_code` UK, `seat_no`.

**`interview_schedule`**: `schedule_id` PK, `application_id`/`committee_id` FK, `scheduled_at`, `location_or_link`, `status` (SCHEDULED/COMPLETED/CANCELLED).

**`exam_score`**: `score_id` PK, `application_id`/`subject_id` FK, UNIQUE(application_id, subject_id), `score` (0–10), `grader_staff_id` FK NULL, `note`, `graded_at`.

**`score_appeal`**: phúc khảo — `appeal_id` PK, `score_id` FK, `reason`, `old_score`, `new_score` (NULL được — chưa xử lý xong), `status` (PENDING/RESOLVED_CHANGED/RESOLVED_UNCHANGED), `resolved_at`.

---

## MIỀN 7 — Xét trúng tuyển

**`admission_benchmark`**: `benchmark_id` PK, `batch_major_id` FK **UNIQUE**, `benchmark_value` (0–10), `decided_by_staff_id` FK NULL, `decided_at`.

**`application_ranking`**: `ranking_id` PK, `application_id` FK **UNIQUE**, `total_score` DECIMAL(6,2) mặc định 0 (**tự động tính lại bởi `sp_recalc_application_total_score` mỗi khi `exam_score` đổi**, kể cả do phúc khảo), `rank_order` (>0).

**`waitlist`**: `waitlist_id` PK, `application_id` FK **UNIQUE**, `rank_order`, `status` (WAITING/PROMOTED/EXPIRED).

**`admission_result`**: `result_id` PK, `application_id` FK **UNIQUE**, `result` (TRUNG_TUYEN/DU_BI/KHONG_TRUNG_TUYEN), **2 cột duyệt riêng biệt** `approved_by_staff_id` + `approved_by_leader_id` (đều FK → staff_account, đều NULL được), `approved_at`, `published_at`.

> **Kiểm soát bảo mật quan trọng (nguyên tắc "4 mắt"):** 2 cột duyệt tách riêng đúng theo quy trình thực tế mô tả trong Use Case — Cán bộ/Hội đồng đề xuất kết quả (`approved_by_staff_id`) rồi **Lãnh đạo Khoa/Viện duyệt cuối** (`approved_by_leader_id`) trước khi `published_at` được set. Tầng ứng dụng **phải** chặn không cho 1 tài khoản tự điền cả 2 cột này. Khi `published_at` được set, trigger tự đồng bộ sang `application.admission_status`.

---

## MIỀN 8 — Ra quyết định & Nhập học

**`admission_decision`**: `decision_id` PK, `batch_id` FK, `decision_no` UK NULL, `decision_date`, `file_path` (văn bản đã ký hoặc chờ ký), `status` (DRAFT/PENDING_SIGN/SIGNED/FAILED_SIGN/ISSUED), `signed_by_staff_id` FK NULL (**phải là role LANH_DAO_KHOA** theo actor), `signed_at`, `signature_ref` (mã tham chiếu chữ ký số).

**`decision_application`**: bảng nối N-N — `detail_id` PK, `decision_id`/`application_id` FK, UNIQUE(decision_id, application_id). *Thiết kế cho phép 1 quyết định chỉ áp dụng cho một số ngành cụ thể của đợt, thông qua liên kết gián tiếp qua `application` — không cần đổi khóa ngoại của `admission_decision`.*

**`enrollment_confirmation`**: `confirmation_id` PK, `application_id` FK **UNIQUE**, `deadline`, `confirmed_at`, `status` (CHUA_XAC_NHAN/DA_XAC_NHAN/TU_CHOI_QUA_HAN).

**`original_document_submission`**: `submission_id` PK, `application_id` FK **UNIQUE**, `submitted_at`, `verified_by_staff_id` FK NULL, `verified_at`, `status` (PENDING/VERIFIED/MISSING).

**`enrollment_completion`**: `completion_id` PK, `application_id` FK **UNIQUE**, `completed_by_staff_id` FK NULL, `completed_at`, `transferred_to_training` (bool), `transfer_ref` (mã hồ sơ bên Phân hệ Đào tạo sau khi chuyển giao — **điểm nối duy nhất giữa 2 phân hệ** trong toàn bộ schema).

---

## MIỀN 9 — Thông báo & Công bố

**`announcement`**: `announcement_id` PK, `batch_id` FK NULL (NULL = thông báo chung toàn hệ thống), `title`, `content`, `status` (DRAFT/PUBLISHED/ARCHIVED), `published_at`, `created_by_staff_id` FK NULL, `created_at`.

**`notification`**: `notification_id` PK, `recipient_type` (CANDIDATE/STAFF), `recipient_id` (⚠️ **polymorphic, không có FK thật** — xem quyết định #2 trong file ERD), `channel` (EMAIL/SMS/SYSTEM), `content`, `status` (PENDING/SENT/FAILED), `sent_at`.

---

## MIỀN 10 — Nhật ký hệ thống

**`audit_log`**: `log_id` PK, `actor_type` (CANDIDATE/STAFF/SYSTEM), `actor_id` NULL (⚠️ polymorphic, cùng lưu ý như trên), `action`, `entity_table`, `entity_id`, `detail` (TEXT), `created_at` (**từ v3 có index riêng**, xem Phụ lục).

---

## Phụ lục A — Index bổ sung (9 cái, + 1 mới ở v3)

| Index | Bảng.Cột | Mục đích |
|---|---|---|
| idx_application_review_status | application(review_status) | Lọc hồ sơ theo trạng thái thẩm định |
| idx_application_admission_status | application(admission_status) | Lọc theo kết quả xét tuyển |
| idx_application_batch_major | application(batch_major_id) | Lọc hồ sơ theo đợt/ngành |
| idx_payment_status | application_payment(gateway_status) | Đối soát thanh toán |
| idx_review_application | application_review(application_id) | Tra cứu lịch sử thẩm định 1 hồ sơ |
| idx_audit_entity | audit_log(entity_table, entity_id) | Tra log theo đối tượng |
| **idx_audit_created_at** | audit_log(created_at) | **Mới (v3)** — báo cáo/audit theo thời gian |
| idx_notification_recipient | notification(recipient_type, recipient_id) | Tra thông báo theo người nhận |
| idx_otp_expires | otp_verification(expires_at) | Dọn OTP hết hạn |
| idx_status_history_application | application_status_history(application_id) | Tra lịch sử 1 hồ sơ |

## Phụ lục B — Stored Procedure & Trigger

- **1 procedure**: `sp_recalc_application_total_score(p_application_id)` — tính lại `total_score` có trọng số (`SUM(score * weight)`) trên `application_ranking`, gọi bởi trigger mỗi khi `exam_score` thay đổi.
- **11 trigger** (đã sửa từ 12 → 11 ở v3): ràng buộc liên bảng & đồng bộ trạng thái mà `CHECK` (chỉ kiểm tra trong 1 dòng) không xử lý được — ví dụ: bậc đào tạo ngành phải khớp bậc đào tạo đợt, đồng bộ `admission_status` khi `admission_result.published_at` được set, ghi `application_status_history` tự động khi `application` đổi trạng thái.

## Phụ lục C — Thay đổi ở v3 (so với v2)

| Thay đổi | Chi tiết |
|---|---|
| `staff_account.password_hash` | `NOT NULL` → `NULL` (dự phòng, Google Login là chính) |
| `candidate_account.password_hash` | `NOT NULL` → `NULL` (lý do tương tự) |
| Index mới | `idx_audit_created_at ON audit_log(created_at)` |
| Comment cuối file | "12 trigger, v2" → "11 trigger, v3" |

*(Toàn bộ quyết định + lý do chi tiết: xem `ERD_PhanHe_TuyenSinh_GD3.md` mục 3. File thực thi: `migration_v3_GD3.sql`.)*
