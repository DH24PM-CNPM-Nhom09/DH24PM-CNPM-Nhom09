# Ma trận Phân quyền (RBAC) — Phân hệ Tuyển sinh

| Mục | Nội dung |
|---|---|
| Người thực hiện | Lâm Hoài An — QA / Security & Data Specialist |
| Theo quyết định | #4 trong `ERD_PhanHe_TuyenSinh_GD3.md` — **không** thêm bảng `permission` vào CSDL, quyền chi tiết kiểm soát bằng code (middleware/guard theo `role_code`), tài liệu này là "nguồn sự thật" để lập trình theo |
| Áp dụng | Backend (middleware/guard mỗi API), QA (viết test case phân quyền) |

## 1. Ánh xạ Actor (Use Case) ↔ `role_code` (bảng `role`)

| Actor (theo Đặc tả Use Case) | `role_code` đề xuất | Ghi chú |
|---|---|---|
| Cán bộ tuyển sinh | `CAN_BO_TUYEN_SINH` | Vận hành nghiệp vụ hàng ngày |
| Hội đồng tuyển sinh / Hội đồng thi | `HOI_DONG` | Thành viên hội đồng — dữ liệu chi tiết nằm ở `committee_member`, không phải `staff_role` (xem lưu ý mục 4) |
| Lãnh đạo Khoa/Viện | `LANH_DAO_KHOA` | Người duyệt cuối + ký số |
| Quản trị hệ thống | `ADMIN` | Toàn quyền kỹ thuật, không thao tác nghiệp vụ xét tuyển |
| Ban Giám hiệu / Phòng KH-TC | `BGH_KHTC` | **Chỉ đọc** — role mới đề xuất bổ sung (schema gốc mới có comment ví dụ 4 role, thiếu role này dù đã có trong danh sách 9 actor) |
| Thí sinh / Ứng viên | *(không phải staff)* | Không dùng `staff_role` — kiểm soát bằng chính danh tính `candidate_id` (chỉ thao tác trên hồ sơ của chính mình) |
| Hệ thống Thanh toán / Ký số / Gửi OTP | *(không phải actor người)* | Xác thực bằng API key/webhook signature riêng, ngoài phạm vi RBAC theo `role_code` |

> Một `staff_account` có thể giữ **nhiều role cùng lúc** (bảng `staff_role` là N-N) — ví dụ vừa `CAN_BO_TUYEN_SINH` vừa `ADMIN`. Khi 1 tài khoản có nhiều role, áp dụng **quyền cao nhất được cấp** (OR logic) trên từng hành động.

## 2. Chú giải ký hiệu

| Ký hiệu | Ý nghĩa |
|---|---|
| **F** | Full — được tạo/sửa/xoá |
| **P** | Propose — được đề xuất/nhập liệu nhưng cần vai trò khác duyệt mới có hiệu lực |
| **A** | Approve — chỉ duyệt/ký, không tự nhập liệu bước trước |
| **R** | Read-only — chỉ xem |
| **–** | Không có quyền truy cập |

## 3. Ma trận quyền theo nhóm chức năng

| Nhóm chức năng (bảng CSDL liên quan) | ADMIN | CAN_BO_TUYEN_SINH | HOI_DONG | LANH_DAO_KHOA | BGH_KHTC |
|---|:---:|:---:|:---:|:---:|:---:|
| Quản lý tài khoản staff & phân role (`staff_account`, `staff_role`, `role`) | **F** | – | – | – | – |
| Cấu hình hệ thống dùng chung (`system_config`) | **F** | – | – | – | – |
| Tạo/sửa đợt tuyển sinh (`admission_batch`) | R | **F** | – | R | R |
| Cấu hình ngành + chỉ tiêu (`admission_batch_major`) | R | **P** | R | **A** | R |
| Cấu hình điều kiện xét tuyển (`admission_condition`) | R | **P** | R | **A** | R |
| Lập hội đồng (`admission_committee`, `committee_member`) | R | **F** | R (xem chính mình) | R | R |
| Cấu hình môn thi (`exam_subject`) | R | **F** | R | R | R |
| Thẩm định hồ sơ, yêu cầu bổ sung (`application_review`, `supplement_request`) | R | **F** | – | R | R |
| Xem/quản lý hồ sơ & minh chứng (`application`, `application_document`) | R | **F** (trừ xoá cứng) | R | R | R (tổng hợp) |
| Xác nhận thanh toán thủ công / đối soát (`application_payment`) | R | **F** | – | R | R |
| Tổ chức thi: phòng thi, số báo danh, lịch phỏng vấn (`exam_room`, `exam_assignment`, `interview_schedule`) | R | **F** | R (lịch của mình) | R | – |
| Chấm điểm & xử lý phúc khảo (`exam_score`, `score_appeal`) | R | R (nhập hộ nếu cần) | **F** | R | – |
| Đề xuất điểm chuẩn (`admission_benchmark`) | R | **P** | **A** | R | – |
| Xếp hạng / danh sách dự bị (`application_ranking`, `waitlist`) | R | R | R | R | R |
| **Duyệt kết quả xét tuyển** (`admission_result`) | R | **P** (`approved_by_staff_id`) | **P/A** (đề xuất & duyệt danh sách) | **A** cuối (`approved_by_leader_id`) | R |
| **Ký số quyết định trúng tuyển** (`admission_decision`) | R | **P** (soạn dự thảo) | – | **A/Sign** (`signed_by_staff_id`) | R |
| Danh sách hồ sơ theo quyết định (`decision_application`) | R | **F** | – | R | R |
| Xác nhận nhập học, nộp bản chính, hoàn tất (`enrollment_confirmation`, `original_document_submission`, `enrollment_completion`) | R | **F** | – | R | R |
| Công bố thông báo (`announcement`) | R | **F** | – | **A** (thông báo cấp khoa/toàn trường) | R |
| Thông báo cá nhân tự động (`notification`) | R | R | R (của mình) | R (của mình) | – |
| **Xem nhật ký hệ thống** (`audit_log`) | **F** (toàn quyền tra cứu) | R (log liên quan hồ sơ mình xử lý) | – | – | – |
| Báo cáo tổng hợp tuyển sinh (dashboard, không sửa dữ liệu) | R | R | R | R | **R (mục đích chính)** |

## 4. Lưu ý triển khai quan trọng cho Backend/DevOps

1. **Nguyên tắc 4 mắt bắt buộc thực thi ở tầng code**, không chỉ ở tài liệu: middleware phải chặn 1 `staff_account` tự set cả `approved_by_staff_id` **và** `approved_by_leader_id` trên cùng 1 `admission_result`; tương tự người soạn `admission_decision` không được tự set `signed_by_staff_id` của chính mình.
2. **`HOI_DONG` không map 1-1 vào `staff_role`** — thành viên hội đồng cụ thể của 1 đợt/ngành nằm trong bảng `committee_member` (gắn với `committee_id`). Middleware cần kiểm tra **2 lớp**: (a) tài khoản có role `HOI_DONG`, **và** (b) tài khoản đó có mặt trong `committee_member` của đúng `committee_id` đang thao tác — tránh trường hợp 1 thành viên hội đồng ngành A chấm điểm/duyệt nhầm sang ngành B.
3. **Thí sinh (candidate) luôn tự giới hạn theo `candidate_id` của JWT/session**, không dùng `role_code` — mọi API phía candidate phải có điều kiện `WHERE candidate_id = :current_candidate_id`, không dựa vào việc client tự truyền `candidate_id`/`application_id`.
4. **`BGH_KHTC` là role chỉ đọc tuyệt đối** — không gắn bất kỳ quyền ghi (F/P/A) nào ở guard, kể cả với các bảng danh mục ít nhạy cảm.
5. Việc phân quyền theo bảng này **kiểm tra ở tầng ứng dụng (middleware/guard theo `role_code` + kiểm tra sở hữu dữ liệu)**, KHÔNG dựa vào ràng buộc CSDL — vì CSDL không có bảng `permission` (theo quyết định #4). QA cần viết test case riêng cho từng dòng "P" và "A" ở mục 3 để đảm bảo không có endpoint nào bỏ sót kiểm tra role.
