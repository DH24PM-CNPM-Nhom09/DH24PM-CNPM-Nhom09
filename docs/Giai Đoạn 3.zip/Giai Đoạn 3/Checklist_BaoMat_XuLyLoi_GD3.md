# Checklist Bảo mật & Xử lý lỗi — Phối hợp Backend / DevOps

| Mục | Nội dung |
|---|---|
| Người thực hiện | Lâm Hoài An — QA / Security & Data Specialist |
| Mục đích | Đưa vào buổi làm việc với DevOps (Võ Trường Hải, Nguyễn Thành Luân) — theo phân công GĐ3: "Hỗ trợ thiết kế xử lý lỗi và bảo mật; Logging, Monitoring và xử lý lỗi hạ tầng" |
| Cách dùng | Mỗi dòng là 1 việc cần làm rõ **ai làm, làm ở đâu** (code hay hạ tầng) — không phải danh sách đã xong |

## 1. Xác thực & phiên đăng nhập

| # | Việc cần làm | Trách nhiệm | Tham chiếu CSDL |
|---|---|---|---|
| 1.1 | Google OAuth2 là đăng nhập chính; token Google phải được verify chữ ký với Google trước khi tin | Backend | — |
| 1.2 | Nếu dùng nhánh dự phòng (password_hash), bắt buộc hash bằng bcrypt/argon2, **không** lưu plaintext hay MD5/SHA thường | Backend | `staff_account.password_hash`, `candidate_account.password_hash` (đã nullable từ v3) |
| 1.3 | Chặn brute-force: tăng `failed_login_count`, set `locked_until` sau N lần sai (thống nhất số N cụ thể, ví dụ 5 lần / khoá 15 phút) | Backend | `candidate_account.failed_login_count`, `locked_until` |
| 1.4 | OTP: chỉ lưu `otp_code_hash`, giới hạn `sent_count`, kiểm tra `expires_at` mỗi lần verify, KHÔNG cho verify lại OTP đã `verified_at` | Backend | `otp_verification` |
| 1.5 | JWT: quy định thời hạn access token ngắn (VD 15-30 phút) + refresh token riêng, refresh token phải revoke được (logout, đổi mật khẩu) | Backend + DevOps | — |
| 1.6 | `staff_account.status = LOCKED/DISABLED` phải chặn đăng nhập ngay ở tầng middleware, không chỉ chặn ở UI | Backend | `staff_account.status` |

## 2. Phân quyền

| # | Việc cần làm | Trách nhiệm | Tham chiếu |
|---|---|---|---|
| 2.1 | Mọi API nội bộ phải qua middleware kiểm tra `role_code` theo đúng bảng ma trận đã chốt | Backend | `MaTranPhanQuyen_GD3.md` |
| 2.2 | API phía thí sinh luôn lọc theo `candidate_id` lấy từ token, không tin `candidate_id`/`application_id` do client gửi lên | Backend | mục 4 của ma trận phân quyền |
| 2.3 | Ghi log mọi lần bị từ chối quyền (403) vào `audit_log` — phục vụ phát hiện dò quét trái phép | Backend + DevOps | `audit_log` |

## 3. Bảo vệ dữ liệu & Upload file

| # | Việc cần làm | Trách nhiệm | Tham chiếu |
|---|---|---|---|
| 3.1 | Kiểm tra dung lượng file **ở tầng ứng dụng trước khi lưu** (≤5MB/tệp, ≤30MB/hồ sơ), không chỉ dựa vào CHECK/trigger của DB để tránh upload thừa lãng phí băng thông | Backend | `application_document.file_size_kb`, trigger `trg_document_size_limit` |
| 3.2 | Tính `file_hash` (SHA-256) ngay khi nhận file, đối chiếu lại khi tải xuống để phát hiện file bị hỏng/chỉnh sửa | Backend | `application_document.file_hash` |
| 3.3 | Giới hạn loại file được upload theo phần mở rộng THẬT (kiểm tra magic bytes, không chỉ đuôi file) — chặn upload file thực thi giả dạng PDF/ảnh | Backend | — (chưa có ràng buộc này trong DB, cần bổ sung ở code) |
| 3.4 | Dữ liệu cá nhân nhạy cảm (`id_number`, `dob`, `address`) — hạn chế field trả về trong API theo đúng role đang gọi (VD: `BGH_KHTC` chỉ thấy dữ liệu tổng hợp, không thấy CCCD từng thí sinh) | Backend | `candidate.id_number`, `dob`, `address` |
| 3.5 | Backup định kỳ cho toàn bộ file minh chứng + database, có lịch test khôi phục thử (không chỉ backup rồi để đó) | DevOps | — |

## 4. Thanh toán (lệ phí xét tuyển)

| # | Việc cần làm | Trách nhiệm | Tham chiếu |
|---|---|---|---|
| 4.1 | Xác minh chữ ký (signature) của callback MoMo/VNPAY trước khi cập nhật `gateway_status` — **đây là điểm HLD ghi "cần đối chiếu lần cuối"**, phải chốt trước khi code | Backend | `application_payment.gateway_status` |
| 4.2 | Idempotency: nếu callback gọi lại nhiều lần (retry từ cổng thanh toán) không được cộng tiền/cập nhật 2 lần — dựa vào `transaction_code` UNIQUE để chặn trùng | Backend | `application_payment.transaction_code` |
| 4.3 | Đối soát định kỳ giữa `gateway_status = SUCCESS` và log thật từ cổng thanh toán, phát hiện lệch sớm | Backend + DevOps | — |
| 4.4 | Không log/lưu thông tin thẻ hay tài khoản ngân hàng đầy đủ ở đâu cả — chỉ lưu `transaction_code`/`receipt_no` | Backend | — |

## 5. Chữ ký số & Tích hợp bên ngoài

| # | Việc cần làm | Trách nhiệm | Tham chiếu |
|---|---|---|---|
| 5.1 | Xác minh `signature_ref` với dịch vụ ký số trước khi set `admission_decision.status = SIGNED` | Backend | `admission_decision.signature_ref` |
| 5.2 | Xử lý rõ trạng thái `FAILED_SIGN` — không được để quyết định "treo" không rõ trạng thái khi dịch vụ ký số lỗi | Backend | `admission_decision.status` |
| 5.3 | Tích hợp HEMIS (đồng bộ Bộ GD&ĐT theo Điều 33.2 TT53): dùng key/chứng chỉ riêng, không dùng chung credential nội bộ; log đầy đủ mỗi lần đồng bộ (thành công/thất bại) | Backend + DevOps | `enrollment_completion.transfer_ref` |

## 6. Logging & Giám sát

| # | Việc cần làm | Trách nhiệm | Tham chiếu |
|---|---|---|---|
| 6.1 | `notification.recipient_id` và `audit_log.actor_id` là khóa tham chiếu **không có FK thật** (polymorphic) — validate tồn tại ở tầng ứng dụng trước khi ghi, tránh log rác trỏ tới ID không tồn tại | Backend | Quyết định #2 trong `ERD_PhanHe_TuyenSinh_GD3.md` |
| 6.2 | Bắt buộc ghi `audit_log` cho: đăng nhập thất bại liên tiếp, duyệt kết quả xét tuyển, ký số quyết định, mọi thao tác xoá mềm | Backend | `audit_log` |
| 6.3 | Dùng index mới `idx_audit_created_at` để dựng dashboard giám sát theo thời gian thực (audit_log sẽ là bảng tăng nhanh nhất hệ thống) | DevOps | `idx_audit_created_at` (đã thêm ở v3) |
| 6.4 | Cảnh báo (alert) tự động khi: tỉ lệ lỗi API tăng đột biến, callback thanh toán thất bại liên tục, dịch vụ ký số/HEMIS không phản hồi | DevOps | — |
| 6.5 | Không log thông tin nhạy cảm (mật khẩu, OTP, toàn bộ `file_hash`+nội dung file) ra log hệ thống (VD log của Render/console) | Backend + DevOps | — |

## 7. Xử lý lỗi chuẩn hoá

| # | Việc cần làm | Trách nhiệm | Tham chiếu |
|---|---|---|---|
| 7.1 | Thống nhất 1 định dạng JSON lỗi chung cho toàn bộ API (VD: `{ "error_code", "message", "detail" }`), không để lộ chi tiết SQL/stack trace ra ngoài | Backend | — |
| 7.2 | Khi vi phạm `CHECK constraint` hoặc trigger chặn (VD: bậc đào tạo ngành không khớp bậc đợt), backend phải bắt lỗi DB và trả về message thân thiện, không trả nguyên lỗi MariaDB cho client | Backend | Trigger `trg_batch_major_degree_check_ins` và 10 trigger còn lại |
| 7.3 | Retry có giới hạn (không retry vô hạn) cho các lời gọi ra ngoài: cổng thanh toán, dịch vụ ký số, HEMIS, gửi OTP/email — kèm cơ chế dead-letter/log lại để xử lý thủ công khi retry hết vẫn lỗi | Backend + DevOps | — |
| 7.4 | Mã hoá HTTP status đúng ngữ nghĩa: 401 (chưa đăng nhập) khác 403 (không đủ quyền) khác 422 (dữ liệu không hợp lệ do vi phạm CHECK/business rule) | Backend | — |

## 8. Hạ tầng & Triển khai (dành riêng cho DevOps)

| # | Việc cần làm |
|---|---|
| 8.1 | Toàn bộ secret (DB password, Google OAuth client secret, key HEMIS, key cổng thanh toán) nằm trong biến môi trường (env var) trên Render, **không** commit vào GitHub |
| 8.2 | Bắt buộc HTTPS toàn bộ, chặn HTTP thuần |
| 8.3 | Cấu hình CORS đúng domain frontend thật, không để `*` ở môi trường production |
| 8.4 | Rate limiting ở tầng API/gateway (không chỉ dựa vào `failed_login_count` trong DB) để chặn tấn công dò mật khẩu/OTP hàng loạt |
| 8.5 | Có môi trường staging riêng để test trigger/migration trước khi chạy lên DB production |

---

*Danh sách này là điểm khởi đầu để họp với DevOps — cần 2 bên cùng đánh dấu việc nào đã làm, việc nào cần làm, ai phụ trách chính thức trước khi đưa vào DDD.*
